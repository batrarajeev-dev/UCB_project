# European Commercial Fleet Telemetry Analysis & Vehicle Classification (`Make_n_Model`)
**Capstone Project — Module 20: Exploratory Data Analysis (EDA) & Baseline Model Report**

![Capstone EDA Visual Summary Dashboard](images/00_eda_visualizations_summary.png)

## 1. Executive Summary & Business Objective

Commercial fleet operators managing diverse multi-brand vehicle fleets across Europe face a core operational optimization problem: matching trip demand profiles (distance, duration, payload weight, fuel budget, and specialized cargo body requirements) to the optimal vehicle make and model. Assigning an oversized heavy-haulage tractor to short regional box deliveries inflates fuel burn and capital depreciation, while under-specifying vehicle capacity risks regulatory gross weight violations and premature mechanical wear.

This Capstone Project (Module 20) analyzes **400,000 synthetic European commercial vehicle trip records** (`synthetic_fleet_data_400k_splneeds.csv`) spanning **January 2018 through December 2023** across **8 European countries**, **10 commercial vehicle manufacturers (OEMs)**, and **21 distinct vehicle models**. Following data cleaning and scope refinement (**391,204 cleaned records**), this report documents:

1. **Data Quality & Preprocessing (`Cells 1–17`)**: Removal of non-predictive identifiers (`trip_id`), exclusion of non-commercial emergency transport records (`special_need == 'Ambulance'`, removing **8,796 rows** or **2.20%**), timestamp standardization, and verification of **0.0% missing values** and **0.0% duplicate rows**.
2. **Target Engineering (`Cells 10–11`)**: Creation of a composite multi-class target variable, **`Make_n_Model`** (`manufacturer + '_' + Model`), resolving potential model-name collisions across OEMs and defining a **21-class supervised classification task**.
3. **Exploratory Data Analysis & Visual Insights (`Cells 18–32`)**: Quantitative and visual investigation of feature distributions, log-scale outlier structures, 5-mode trip duration regimes, 3-tier staircase payload structures, collinearity clusters, and cross-tabulated operational boundaries between `special_need` cargo categories and `Make_n_Model`.
4. **Leakage-Safe Baseline Modeling Strategy (`Cells 33–36`)**: Identification of deterministic identifier/leakage columns (`manufacturer`, `Model`, `Group`, `wmi`, `plant`, `Serial Number`) and constant features (`Region = 'Europe'`), paired with exact baseline accuracy benchmarks (**5.44% Dummy Majority $\rightarrow$ 28.36% `special_need` Lookup $\rightarrow$ 40.85% Pure Telemetry Track A $\rightarrow$ 70.50% Telemetry + Weight Specs Track B**) and a complete `scikit-learn` pipeline.

## 2. Cell-by-Cell Walkthrough of `Capstone_project_EDASubmission_Module20.ipynb`

| Notebook Cells | Stage | Action Performed in Code | Key Output & Analytical Finding |
| :--- | :--- | :--- | :--- |
| **Cell 0** | Environment Setup | Imports `pandas`, `numpy`, `seaborn`, `matplotlib`, `plotly`, `ydata_profiling`, and `scikit-learn` modules (`LogisticRegression`, `SVC`, `RandomForestClassifier`, `KNeighborsClassifier`, `DecisionTreeClassifier`, `ColumnTransformer`, `Pipeline`, `StandardScaler`, `OneHotEncoder`) | All required EDA, preprocessing, and baseline modeling libraries are pre-loaded at the top of the notebook |
| **Cells 1–3** | Data Ingestion | `vtd_df = pd.read_csv('data/synthetic_fleet_data_400k_splneeds.csv')` and `vtd_df.head()` | Loads **400,000 rows × 19 columns** of European commercial trip telemetry |
| **Cell 4** | Feature Dictionary | Markdown documentation of dataset variables | Documents all 19 columns (also notes `Asset_ID`, which is represented by `Serial Number` in the CSV) |
| **Cells 5–6** | Schema Inspection | `vtd_df.describe()` and `vtd_df.info()` | Confirms **400,000 non-null entries** across `float64(5)`, `int64(3)`, and `object(11)` (`58.0+ MB` RAM) |
| **Cells 7–8** | Data Cleaning | Drops `trip_id` and filters `vtd_df[vtd_df['special_need'].str.lower() != 'ambulance']` | Removes **8,796 Ambulance trips (2.20%)**, leaving **391,204 clean commercial freight rows** |
| **Cell 9** | Date Parsing | Converts `trip_start_time` and `trip_end_time` via `pd.to_datetime(...).dt.date` | Standardizes timestamps to calendar dates spanning **2018-01-01 to 2023-12-31** (end dates to **2024-01-03**) |
| **Cells 10–12** | Target Engineering | Creates `vtd_df['Make_n_Model'] = vtd_df['manufacturer'] + '_' + vtd_df['Model']` and sets `target_col = 'Make_n_Model'` | Defines the **21-class target variable** (`Hino_500 Series`, `Renault_T High`, `Scania_R-Series`, `Volvo_FH16`, etc.) |
| **Cells 13–15** | Domain Cardinality | Inspects `vtd_df['Capacity'].unique()` and `vtd_df[target_col].unique()` | Confirms **9 discrete payload capacities** (`1.5, 2.5, 4.0, 6.0, 8.0, 9.0, 10.0, 24.0, 40.0` tonnes) and **21 unique `Make_n_Model` classes** |
| **Cells 16–17** | Missing Data Audit | Runs `vtd_df.isnull().sum()` and plots `sns.heatmap(vtd_df.isna())` (`images/01_missing_values_heatmap.png`) | Confirms **0 missing values (0.0%)** across all 19 columns and 391,204 rows |
| **Cells 18–19** | Automated Profiling | Runs `ProfileReport(vtd_df, explorative=True)` and exports `vehicle_trip_profile_report.html` | Identifies **0 duplicate rows**, **15 alerts** (constant `Region = "Europe"` and 14 high-correlation alerts), and full quantile statistics |
| **Cell 20** | Correlation Matrix | Computes `vtd_df.corr(numeric_only=True)` and plots annotated heatmap (`images/02_correlation_matrix_heatmap.png`) | Reveals two strongly collinear blocks: **Telemetry Block** ($r = 0.974\text{–}0.991$) and **Weight Spec Block** ($r = 0.869\text{–}0.975$) |
| **Cells 21–23** | Special Need Boxplots | Interactive Plotly boxplots of `special_need` vs. `trip_duration` (Cell 21), `total_fuel` (Cell 22), and `total_distance` (Cell 23) (`images/03_special_need_boxplots.png`) | Segments cargo types into Long-Haul Heavy (`Heavy Haulage`, `Timber`, `Container`), Mixed (`Curtainsider`, `Refrigerated`, `Tipper`), and Short-Haul (`Box`, `Flatbed`, `Refuse`, `Panel Van`) |
| **Cells 24 & 27** | Category Volumes | Plots horizontal Viridis bar chart (`images/04_top_special_need_categories.png`) and alphabetical bar chart (`images/07_special_need_sorted_bar.png`) | Shows top 3 categories (`Box` `91,111`, `Refrigerated` `87,065`, `Curtainsider` `79,073`) represent **65.76% of all fleet trips** |
| **Cells 25–26** | Duration Regimes | Plots `total_distance` vs. `trip_duration` scatter (`images/05_distance_vs_duration_scatter.png`) and 50-bin KDE histogram (`images/06_trip_duration_distribution.png`) | Uncovers **5 multi-modal trip duration bands** (`<12.5h`, `21–32h`, `43–54h`, `64–75h`, `85–92h`) driven by mandatory overnight tachograph rest periods |
| **Cell 28** | Target vs. Special Need | Builds stacked bar chart of `pd.crosstab(vtd_df['Make_n_Model'], vtd_df['special_need'])` (`images/08_make_model_vs_special_need_stacked.png`) | Demonstrates that every `Make_n_Model` operates in **only 1 to 3 specific `special_need` categories** |
| **Cell 29** | Temporal Volume | Plots 6-bin histogram of `trip_start_time` (`images/09_yearly_trip_distribution.png`) | Confirms uniform annual trip volume (**~65,200 trips/year** from 2018 to 2023) |
| **Cell 30** | Outlier Detection | Plots horizontal log-scale boxplot of numerical features (`images/10_numerical_outliers_boxplot.png`) | Visualizes multi-order-of-magnitude scale spread (`10^0` to `10^5.5`), motivating `StandardScaler` normalization |
| **Cell 31** | Feature Pairplot | Plots 7-variable corner pairplot with KDE diagonals (`images/11_numerical_features_pairplot.png`) | Reveals the **3-tier staircase structure** (Light, Medium, Heavy vehicles) in `axle_weight_average` vs. `total_distance` and `total_fuel` |
| **Cell 32** | Groupby Baseline | Runs `vtd_df.groupby('special_need')[target_col].describe()` | Establishes the single-feature `special_need` lookup baseline (**110,928 / 391,204 = 28.36% accuracy**) |
| **Cells 33–36** | Baseline Modeling | Implements feature engineering, leakage removal, stratified 80/20 split, `ColumnTransformer`, and baseline classifiers (`images/12_baseline_model_progression.png`) | Benchmarks **Multinomial Logistic Regression**, **Decision Tree**, and **Random Forest** across Track A (**40.85%**) and Track B (**70.50%**) |

## 3. Dataset Overview, Schema Dictionary & Data Cleaning

### 3.1 High-Level Dataset Summary (`ydata-profiling` Audit)

| Metric | Raw Dataset | Cleaned EDA Dataset | Analytical & Modeling Impact |
| :--- | ---: | ---: | :--- |
| **Total Observations (Rows)** | 400,000 | 391,204 | **8,796 rows (`2.20%`)** removed where `special_need == 'Ambulance'` |
| **Total Columns** | 19 | 19 | `trip_id` dropped (`-1`); `Make_n_Model` target engineered (`+1`) |
| **Missing Cells** | 0 (`0.0%`) | 0 (`0.0%`) | Confirmed via `vtd_df.isnull().sum()` and Cell 17 heatmap |
| **Duplicate Rows** | 0 (`0.0%`) | 0 (`0.0%`) | Zero duplicate trip records |
| **Memory Footprint** | 58.0+ MB | 263.2 MiB (profiled) | 7 numerical, 9 categorical, 2 date, and 1 text (`Serial Number`) variables |
| **Date Coverage** | 2018-01-01 to 2023-12-31 | 2018-01-01 to 2023-12-31 | 2,191 distinct start dates; `trip_end_time` extends to 2024-01-03 (2,194 dates) |

### 3.2 Complete Feature Dictionary & Leakage Audit

| # | Column Name | Dtype | Distinct | Example Values | Description | ML Pipeline Role |
| :-: | :--- | :--- | ---: | :--- | :--- | :--- |
| 1 | `trip_id` | `int64` | 400,000 | `158815423` | Unique trip record key | **Dropped in Cell 8** (Zero predictive power) |
| 2 | `trip_start_time` | `date` | 2,191 | `2022-11-07` | Trip start date | **Engineer & Drop Raw** (Extract `trip_month`, `trip_dayofweek`) |
| 3 | `trip_end_time` | `date` | 2,194 | `2022-11-07` | Trip completion date | **Engineer & Drop Raw** (Extract `trip_span_days`) |
| 4 | `trip_duration` | `int64` | 108,270 | `18985`, `241463` | Total trip duration in seconds (`305` to `332,649 s`) | **Core Numerical Feature** (Telemetry) |
| 5 | `total_distance` | `float64` | 153,172 | `337.59`, `2246.18` | Total trip distance in km (`5.00` to `2,499.99 km`) | **Core Numerical Feature** (Telemetry) |
| 6 | `total_fuel` | `float64` | 74,026 | `64.02`, `671.50` | Total fuel consumed in litres (`0.41` to `874.01 L`) | **Core Numerical Feature** (Telemetry) |
| 7 | `axle_weight_average` | `int64` | 10,501 | `3338`, `11019` | Average axle load in kg (`1,000` to `11,500 kg`) | **Core Numerical Feature** (Payload Telemetry) |
| 8 | `special_need` | `object` | 10 | `Box`, `Refrigerated` | Cargo body / special operational requirement | **Core Categorical Feature** (`OneHotEncoder`) |
| 9 | `Country` | `object` | 8 | `France`, `Italy` | Country of operation (8 European markets) | **Categorical Feature** (`OneHotEncoder`) |
| 10 | `GCW` | `float64` | 11 | `32.0`, `44.0`, `60.0` | Gross Combination Weight (`6.0` to `60.0 t`) | **Static Vehicle Spec** (Used in Track B; omitted in Track A) |
| 11 | `GVW` | `float64` | 10 | `16.0`, `26.0`, `32.0` | Gross Vehicle Weight (`3.5` to `32.0 t`) | **Static Vehicle Spec** (Used in Track B; omitted in Track A) |
| 12 | `Capacity` | `float64` | 9 | `9.0`, `24.0`, `40.0` | Maximum payload capacity (`1.5` to `40.0 t`) | **Static Vehicle Spec** (Used in Track B; omitted in Track A) |
| 13 | `Region` | `object` | 1 | `Europe` | Geographic region (`100%` `"Europe"`) | **Drop — Constant Feature** (Zero variance across all rows) |
| 14 | `Serial Number` | `object` | 4,879 | `EU107265` | Unique physical vehicle ID (`EU` + 6 digits) | **Drop — Target Leakage** (Maps 1:1 to a single `Make_n_Model`) |
| 15 | `Group` | `object` | 21 | `JHD500SERIES` | Internal fleet group code (`wmi + Model`) | **Drop — Target Leakage** (1:1 deterministic alias of `Make_n_Model`) |
| 16 | `manufacturer` | `object` | 10 | `Volvo`, `MAN` | Vehicle OEM brand | **Drop — Direct Target Leakage** (First half of target string) |
| 17 | `Model` | `object` | 21 | `500 Series`, `FH16` | Vehicle model name | **Drop — Direct Target Leakage** (Second half of target string) |
| 18 | `wmi` | `object` | 11 | `YV2`, `WMA`, `ZCF` | World Manufacturer Identifier | **Drop — Target Leakage** (Maps deterministically to `manufacturer`) |
| 19 | `plant` | `object` | 44 | `YV2PLANT1` | Operating plant code (`wmi + PLANT1..4`) | **Drop — Target Leakage** (Prefix leaks `wmi` and `manufacturer`) |
| 20 | **`Make_n_Model`** | `object` | **21** | `Hino_500 Series` | **Target Variable (`y`)**: `manufacturer + '_' + Model` | **Target Label (`y`)** |

### 3.3 Missing Data Evaluation (`Cells 16–17`)

In **Cell 17**, `sns.heatmap(vtd_df.isna())` evaluates missingness across all `391,204` rows and `19` columns, confirming **0.0% missing values**:

![Missing Values Heatmap](images/01_missing_values_heatmap.png)

## 4. Exploratory Data Analysis (EDA) & Visual Findings

### 4.1 Numerical Feature Distributions & Log-Scale Outlier Detection (`Cells 5, 19, 30`)

Because the 7 numerical variables span five orders of magnitude (`Capacity` starting at `1.5 tonnes` vs. `trip_duration` reaching `332,649 seconds`), **Cell 30** plots horizontal boxplots on a logarithmic scale (`plt.xscale('log')`):

![Log-Scale Numerical Outlier Boxplot](images/10_numerical_outliers_boxplot.png)

| Numerical Feature | Mean | Std Dev | Min | 5th % | Q1 (25%) | Median (50%) | Q3 (75%) | 95th % | Max | IQR | Skewness | CV |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| **`trip_duration` (s)** | 70,067.53 | 85,129.21 | 305.00 | 2,742.00 | 8,879.00 | 22,472.00 | 108,458.50 | 247,451.00 | 332,649.00 | 99,579.50 | +1.192 | 1.215 |
| **`total_distance` (km)** | 700.94 | 744.27 | 5.00 | 32.87 | 117.17 | 343.18 | 1,222.42 | 2,247.56 | 2,499.99 | 1,105.25 | +1.012 | 1.062 |
| **`total_fuel` (L)** | 199.30 | 232.36 | 0.41 | 3.66 | 15.54 | 72.69 | 363.12 | 674.06 | 874.01 | 347.58 | +1.048 | 1.166 |
| **`axle_weight_average` (kg)** | 5,907.91 | 3,073.89 | 1,000.00 | 1,387.00 | 2,925.00 | 6,145.00 | 8,439.00 | 10,888.00 | 11,500.00 | 5,514.00 | +0.076 | 0.520 |
| **`GCW` (tonnes)** | 31.87 | 16.46 | 6.00 | 7.00 | 11.00 | 32.00 | 44.00 | 60.00 | 60.00 | 33.00 | -0.115 | 0.516 |
| **`GVW` (tonnes)** | 18.15 | 8.73 | 3.50 | 5.00 | 7.50 | 18.00 | 26.00 | 32.00 | 32.00 | 18.50 | -0.252 | 0.481 |
| **`Capacity` (tonnes)** | 15.66 | 11.73 | 1.50 | 2.50 | 4.00 | 10.00 | 24.00 | 40.00 | 40.00 | 20.00 | +0.584 | 0.749 |

### 4.2 Correlation Analysis & Multicollinearity Structure (`Cell 20`)

**Cell 20** computes `vtd_df.corr(numeric_only=True)` and renders an annotated heatmap revealing **two tightly coupled collinear clusters**:

![Correlation Matrix Heatmap](images/02_correlation_matrix_heatmap.png)

| Feature | `trip_duration` | `total_distance` | `total_fuel` | `axle_weight_average` | `GCW` | `GVW` | `Capacity` |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| **`trip_duration`** | **1.0000** | **0.9824** | **0.9736** | 0.6432 | 0.6604 | 0.6825 | 0.6892 |
| **`total_distance`** | **0.9824** | **1.0000** | **0.9908** | 0.6921 | 0.7132 | 0.7359 | 0.7331 |
| **`total_fuel`** | **0.9736** | **0.9908** | **1.0000** | 0.6948 | 0.7146 | 0.7380 | 0.7405 |
| **`axle_weight_average`** | 0.6432 | 0.6921 | 0.6948 | **1.0000** | **0.8695** | **0.8896** | **0.8210** |
| **`GCW`** | 0.6604 | 0.7132 | 0.7146 | **0.8695** | **1.0000** | **0.9749** | **0.9567** |
| **`GVW`** | 0.6825 | 0.7359 | 0.7380 | **0.8896** | **0.9749** | **1.0000** | **0.9254** |
| **`Capacity`** | 0.6892 | 0.7331 | 0.7405 | **0.8210** | **0.9567** | **0.9254** | **1.0000** |

### 4.3 Multi-Modal Trip Duration & 3-Tier Staircase Pairplot (`Cells 25, 26, 31`)

In **Cell 25** (`images/05_distance_vs_duration_scatter.png`), **Cell 26** (`images/06_trip_duration_distribution.png`), and **Cell 31** (`images/11_numerical_features_pairplot.png`), the data reveals two structural signatures of commercial European fleet operations:

1. **Five Multi-Modal Trip Duration Peaks (`Cells 25 & 26`)**:
   - `trip_duration` separates into **5 discrete operational regimes** separated by mandatory EU tachograph daily rest periods (`11 hours = 39,600 seconds`) between driving shifts on multi-day trips:

![Total Distance vs Trip Duration Scatter](images/05_distance_vs_duration_scatter.png)

![Trip Duration Distribution Histogram](images/06_trip_duration_distribution.png)

2. **Three-Tier Vehicle Staircase in the Corner Pairplot (`Cell 31`)**:
   - Inspecting the pairplot scatter subplots of `axle_weight_average`, `total_distance`, and `total_fuel` uncovers **3 exact operational vehicle tiers** built into the dataset:
     - **Tier 1 — Light Commercial Vans (`GCW 6–11t, Cap 1.5–4t`)**: Distance `5–150 km`, Fuel Rate `8–15 L/100km`, Axle Weight `1,000–3,000 kg`.
     - **Tier 2 — Medium-Duty Rigid Trucks (`GCW 24–32t, Cap 6–10t`)**: Distance `50–450 km`, Fuel Rate `15–25 L/100km`, Axle Weight `3,000–7,000 kg`.
     - **Tier 3 — Heavy-Duty Articulated Trucks (`GCW 44–60t, Cap 24–40t`)**: Distance `200–2,500 km`, Fuel Rate `25–35 L/100km`, Axle Weight `6,000–11,500 kg`.

![Numerical Features Corner Pairplot](images/11_numerical_features_pairplot.png)

### 4.4 Special Need Category Distribution & Boxplots (`Cells 21–24, 27, 32`)

**Cells 21, 22, and 23** compare `trip_duration`, `total_fuel`, and `total_distance` across all 10 `special_need` cargo categories, while **Cells 24 and 27** rank the category trip counts:

![Special Need Boxplots (Duration, Fuel, Distance)](images/03_special_need_boxplots.png)

![Top Special Need Categories](images/04_top_special_need_categories.png)

![Special Need Alphabetical Bar Chart](images/07_special_need_sorted_bar.png)

| Special Need | Trip Count | Share (%) | Unique Models | Mode (`top`) Vehicle in Cell 32 | Mode `freq` (Share of Category) | Median Duration (s / hrs) | Distance Q1 – Median – Q3 (km) | Fuel Q1 – Median – Q3 (L) | Active Weight Tiers |
| :--- | ---: | ---: | ---: | :--- | ---: | ---: | ---: | ---: | :--- |
| **Box** | 91,111 | 23.29% | 10 | `Mercedes_Atego` | 10,482 (`11.5%`) | 10,321 s (2.87 h) | 79.2 – **137.8** – 281.9 | 10.3 – **22.6** – 55.3 | Light (4), Medium (6) |
| **Refrigerated** | 87,065 | 22.26% | 10 | `Mercedes_Actros` | 11,260 (`12.9%`) | 79,774 s (22.16 h) | 119.0 – **698.6** – 1,600.8 | 13.9 – **208.4** – 474.6 | Light (3), Med (1), Heavy (6) |
| **Curtainsider** | 79,073 | 20.21% | 9 | `Volvo_FH` | 10,447 (`13.2%`) | 97,499 s (27.08 h) | 377.5 – **1,001.9** – 1,753.2 | 88.2 – **297.5** – 520.7 | Medium (2), Heavy (7) |
| **Panel Van** | 29,305 | 7.49% | 3 | `Mercedes_Sprinter` | 10,526 (`35.9%`) | 6,519 s (1.81 h) | 40.5 – **77.0** – 113.6 | 4.5 – **8.6** – 12.7 | Light (3) |
| **Heavy Haulage** | 28,387 | 7.26% | 2 | `Volvo_FH16` | 20,667 (`72.8%`) | 157,339 s (43.71 h) | 779.3 – **1,358.4** – 1,941.0 | 231.5 – **402.7** – 576.7 | Heavy (2) |
| **Tipper** | 20,947 | 5.35% | 3 | `Iveco_Eurocargo` | 7,612 (`36.3%`) | 21,725 s (6.03 h) | 192.4 – **321.7** – 497.0 | 37.3 – **64.4** – 144.6 | Medium (2), Heavy (1) |
| **Flatbed** | 20,121 | 5.14% | 2 | `Hino_500 Series` | 11,238 (`55.9%`) | 10,018 s (2.78 h) | 75.6 – **131.7** – 270.6 | 9.5 – **19.5** – 53.0 | Light (1), Medium (1) |
| **Container** | 16,091 | 4.11% | 2 | `Iveco_S-Way` | 9,592 (`59.6%`) | 156,209 s (43.39 h) | 766.2 – **1,339.1** – 1,918.0 | 229.0 – **396.9** – 570.7 | Heavy (2) |
| **Refuse** | 9,738 | 2.49% | 1 | `Volvo_FL` | 9,738 (**`100.0%`**) | 15,138 s (4.21 h) | 149.3 – **252.2** – 352.7 | 29.1 – **49.2** – 69.0 | Medium (1) |
| **Timber** | 9,366 | 2.39% | 1 | `Scania_S-Series V8` | 9,366 (**`100.0%`**) | 156,900 s (43.58 h) | 772.9 – **1,345.7** – 1,917.7 | 228.0 – **397.9** – 570.8 | Heavy (1) |

### 4.5 Target (`Make_n_Model`) vs. `special_need` Stacked Distribution (`Cell 28`)

In **Cell 28**, the stacked bar chart of `pd.crosstab(vtd_df['Make_n_Model'], vtd_df['special_need'])` reveals that every vehicle model operates in only **1, 2, or at most 3 `special_need` categories**:

![Make and Model vs Special Need Stacked Bar Chart](images/08_make_model_vs_special_need_stacked.png)

| Rank | `Make_n_Model` (Target `y`) | Total Trips | Share (%) | Weight Tier | `GCW` (t) | `GVW` (t) | `Capacity` (t) | Exact `special_need` Breakdown |
| :-: | :--- | ---: | ---: | :---: | ---: | ---: | ---: | :--- |
| 1 | **`Hino_500 Series`** | 21,272 | 5.44% | Medium | 32.0 | 16.0 | 9.0 | `Flatbed` (11,238), `Box` (10,034) |
| 2 | **`Volvo_FH16`** | 20,667 | 5.28% | Heavy | 60.0 | 32.0 | 40.0 | `Heavy Haulage` (20,667) |
| 3 | **`Mercedes_Actros`** | 20,652 | 5.28% | Heavy | 44.0 | 26.0 | 24.0 | `Refrigerated` (11,260), `Curtainsider` (9,392) |
| 4 | **`Mercedes_Atego`** | 20,217 | 5.17% | Medium | 28.0 | 15.0 | 8.0 | `Box` (10,482), `Curtainsider` (9,735) |
| 5 | **`Scania_R-Series`** | 19,972 | 5.11% | Heavy | 44.0 | 26.0 | 24.0 | `Curtainsider` (7,038), `Container` (6,499), `Refrigerated` (6,435) |
| 6 | **`DAF_XG+`** | 19,935 | 5.10% | Heavy | 44.0 | 26.0 | 24.0 | `Refrigerated` (11,092), `Curtainsider` (8,843) |
| 7 | **`Volvo_FH`** | 19,726 | 5.04% | Heavy | 44.0 | 26.0 | 24.0 | `Curtainsider` (10,447), `Refrigerated` (9,279) |
| 8 | **`Renault_T High`** | 19,593 | 5.01% | Heavy | 44.0 | 26.0 | 24.0 | `Refrigerated` (10,082), `Curtainsider` (9,511) |
| 9 | **`MAN_TGX`** | 19,444 | 4.97% | Heavy | 44.0 | 26.0 | 24.0 | `Refrigerated` (7,405), `Curtainsider` (6,076), `Tipper` (5,963) |
| 10 | **`Volvo_FL`** | 19,015 | 4.86% | Medium | 25.0 | 16.0 | 9.0 | `Refuse` (9,738), `Box` (9,277) |
| 11 | **`MAN_TGL`** | 18,998 | 4.86% | Medium | 24.0 | 12.0 | 6.0 | `Box` (10,178), `Curtainsider` (8,820) |
| 12 | **`Fuso_Canter`** | 18,976 | 4.85% | Light | 11.0 | 7.5 | 4.0 | `Box` (9,508), `Refrigerated` (9,468) |
| 13 | **`MAN_TGE`** | 18,870 | 4.82% | Light | 7.0 | 3.5 | 1.5 | `Box` (9,770), `Panel Van` (9,100) |
| 14 | **`Iveco_S-Way`** | 18,803 | 4.81% | Heavy | 44.0 | 26.0 | 24.0 | `Container` (9,592), `Curtainsider` (9,211) |
| 15 | **`Isuzu_N-Series`** | 18,094 | 4.63% | Light | 11.0 | 7.5 | 4.0 | `Box` (9,211), `Flatbed` (8,883) |
| 16 | **`DAF_LF`** | 17,753 | 4.54% | Medium | 24.0 | 12.0 | 6.0 | `Tipper` (7,372), `Box` (5,326), `Refrigerated` (5,055) |
| 17 | **`Renault_Master`** | 17,651 | 4.51% | Light | 6.0 | 3.5 | 1.5 | `Panel Van` (9,679), `Refrigerated` (7,972) |
| 18 | **`Iveco_Daily`** | 17,402 | 4.45% | Light | 10.5 | 7.2 | 4.0 | `Refrigerated` (9,017), `Box` (8,385) |
| 19 | **`Scania_S-Series V8`** | 17,086 | 4.37% | Heavy | 60.0 | 26.0 | 40.0 | `Timber` (9,366), `Heavy Haulage` (7,720) |
| 20 | **`Iveco_Eurocargo`** | 16,552 | 4.23% | Medium | 32.0 | 18.0 | 10.0 | `Box` (8,940), `Tipper` (7,612) |
| 21 | **`Mercedes_Sprinter`** | 10,526 | 2.69% | Light | 7.5 | 5.0 | 2.5 | `Panel Van` (10,526) |

### 4.6 Yearly & Geographic Distributions (`Cell 29` & `ProfileReport`)

![Yearly Distribution of Trips](images/09_yearly_trip_distribution.png)

- **Uniform Annual Trip Volume (`2018–2023`)**: `2018` (`64,979`, `16.61%`), `2019` (`65,270`, `16.68%`), `2020` (`65,346`, `16.70%`), `2021` (`65,238`, `16.68%`), `2022` (`65,215`, `16.67%`), `2023` (`65,156`, `16.66%`).
- **Geographic Distribution (`Country` & `Region`)**: `Region` is 100% constant (`"Europe"`), while `Country` is uniformly distributed across **France** (`52,022`, `13.30%`), **Netherlands** (`50,874`, `13.00%`), **Italy** (`50,124`, `12.81%`), **Sweden** (`49,085`, `12.55%`), **Germany** (`47,928`, `12.25%`), **Belgium** (`47,529`, `12.15%`), **Poland** (`47,463`, `12.13%`), and **Spain** (`46,179`, `11.80%`).

## 5. Baseline Machine Learning Model Strategy & Exact Performance Benchmarks

### 5.1 Step-by-Step Guide to Creating the Baseline Model

1. **Step 1 — Prevent Data Leakage (`Critical Gate`)**: Exclude `manufacturer`, `Model`, `Group`, `wmi`, `plant`, and `Serial Number` (which deterministically encode `Make_n_Model`), and drop constant `Region`.
2. **Step 2 — Engineer Physical Telemetry Ratios**: Create `avg_speed_kmh = total_distance / (trip_duration / 3600)`, `fuel_efficiency_km_per_l = total_distance / total_fuel`, `fuel_consumption_l_per_100km = (total_fuel / total_distance) * 100`, `fuel_burn_rate_l_per_hr = total_fuel / (trip_duration / 3600)`, `trip_span_days`, `trip_month`, and `trip_dayofweek`.
3. **Step 3 — Stratified Train/Test Split (`80% Train / 20% Test`)**: Split `391,204` rows into `312,963` training rows and `78,241` test rows using `train_test_split(X, y, test_size=0.20, stratify=y, random_state=42)`.
4. **Step 4 — Preprocessing via `ColumnTransformer`**: Apply `SimpleImputer(strategy='median')` + `StandardScaler()` to numerical features and `SimpleImputer(strategy='most_frequent')` + `OneHotEncoder(handle_unknown='ignore')` to `special_need` and `Country`.
5. **Step 5 — Benchmark Across Feature Tiers**:

![Baseline Model Accuracy Progression & Recall Breakdown](images/12_baseline_model_progression.png)

### 5.2 Complete 29-Bucket Classification Breakdown (Track A vs. Track B)

| # | `special_need` | Telemetry Tier | Weight Specs `(GCW, GVW, Cap)` | Competing Models in Bucket | Bucket Trips | Majority (`Top`) Model | Track B Bucket Accuracy |
| :-: | :--- | :---: | :---: | :--- | ---: | :--- | ---: |
| 1 | `Box` | Light | `(7.0, 3.5, 1.5)` | `MAN_TGE` (1 model) | 9,770 | `MAN_TGE` | **100.0%** (9,770 / 9,770) |
| 2 | `Box` | Light | `(10.5, 7.2, 4.0)` | `Iveco_Daily` (1 model) | 8,385 | `Iveco_Daily` | **100.0%** (8,385 / 8,385) |
| 3 | `Box` | Light | `(11.0, 7.5, 4.0)` | `Fuso_Canter` (9,508), `Isuzu_N-Series` (9,211) | 18,719 | `Fuso_Canter` | **50.8%** (9,508 / 18,719) |
| 4 | `Box` | Medium | `(24.0, 12.0, 6.0)` | `MAN_TGL` (10,178), `DAF_LF` (5,326) | 15,504 | `MAN_TGL` | **65.6%** (10,178 / 15,504) |
| 5 | `Box` | Medium | `(25.0, 16.0, 9.0)` | `Volvo_FL` (1 model) | 9,277 | `Volvo_FL` | **100.0%** (9,277 / 9,277) |
| 6 | `Box` | Medium | `(28.0, 15.0, 8.0)` | `Mercedes_Atego` (1 model) | 10,482 | `Mercedes_Atego` | **100.0%** (10,482 / 10,482) |
| 7 | `Box` | Medium | `(32.0, 16.0, 9.0)` | `Hino_500 Series` (1 model) | 10,034 | `Hino_500 Series` | **100.0%** (10,034 / 10,034) |
| 8 | `Box` | Medium | `(32.0, 18.0, 10.0)` | `Iveco_Eurocargo` (1 model) | 8,940 | `Iveco_Eurocargo` | **100.0%** (8,940 / 8,940) |
| 9 | `Container` | Heavy | `(44.0, 26.0, 24.0)` | `Iveco_S-Way` (9,592), `Scania_R-Series` (6,499) | 16,091 | `Iveco_S-Way` | **59.6%** (9,592 / 16,091) |
| 10 | `Curtainsider` | Medium | `(24.0, 12.0, 6.0)` | `MAN_TGL` (1 model) | 8,820 | `MAN_TGL` | **100.0%** (8,820 / 8,820) |
| 11 | `Curtainsider` | Medium | `(28.0, 15.0, 8.0)` | `Mercedes_Atego` (1 model) | 9,735 | `Mercedes_Atego` | **100.0%** (9,735 / 9,735) |
| 12 | `Curtainsider` | Heavy | `(44.0, 26.0, 24.0)` | 7 Heavy 44t Models (`Volvo_FH`, `Renault_T High`, `Mercedes_Actros`, `Iveco_S-Way`, `DAF_XG+`, `Scania_R-Series`, `MAN_TGX`) | 60,518 | `Volvo_FH` | **17.3%** (10,447 / 60,518) |
| 13 | `Flatbed` | Light | `(11.0, 7.5, 4.0)` | `Isuzu_N-Series` (1 model) | 8,883 | `Isuzu_N-Series` | **100.0%** (8,883 / 8,883) |
| 14 | `Flatbed` | Medium | `(32.0, 16.0, 9.0)` | `Hino_500 Series` (1 model) | 11,238 | `Hino_500 Series` | **100.0%** (11,238 / 11,238) |
| 15 | `Heavy Haulage` | Heavy | `(60.0, 26.0, 40.0)` | `Scania_S-Series V8` (1 model) | 7,720 | `Scania_S-Series V8` | **100.0%** (7,720 / 7,720) |
| 16 | `Heavy Haulage` | Heavy | `(60.0, 32.0, 40.0)` | `Volvo_FH16` (1 model) | 20,667 | `Volvo_FH16` | **100.0%** (20,667 / 20,667) |
| 17 | `Panel Van` | Light | `(6.0, 3.5, 1.5)` | `Renault_Master` (1 model) | 9,679 | `Renault_Master` | **100.0%** (9,679 / 9,679) |
| 18 | `Panel Van` | Light | `(7.0, 3.5, 1.5)` | `MAN_TGE` (1 model) | 9,100 | `MAN_TGE` | **100.0%** (9,100 / 9,100) |
| 19 | `Panel Van` | Light | `(7.5, 5.0, 2.5)` | `Mercedes_Sprinter` (1 model) | 10,526 | `Mercedes_Sprinter` | **100.0%** (10,526 / 10,526) |
| 20 | `Refrigerated` | Light | `(6.0, 3.5, 1.5)` | `Renault_Master` (1 model) | 7,972 | `Renault_Master` | **100.0%** (7,972 / 7,972) |
| 21 | `Refrigerated` | Light | `(10.5, 7.2, 4.0)` | `Iveco_Daily` (1 model) | 9,017 | `Iveco_Daily` | **100.0%** (9,017 / 9,017) |
| 22 | `Refrigerated` | Light | `(11.0, 7.5, 4.0)` | `Fuso_Canter` (1 model) | 9,468 | `Fuso_Canter` | **100.0%** (9,468 / 9,468) |
| 23 | `Refrigerated` | Medium | `(24.0, 12.0, 6.0)` | `DAF_LF` (1 model) | 5,055 | `DAF_LF` | **100.0%** (5,055 / 5,055) |
| 24 | `Refrigerated` | Heavy | `(44.0, 26.0, 24.0)` | 6 Heavy 44t Models (`Mercedes_Actros`, `DAF_XG+`, `Renault_T High`, `Volvo_FH`, `MAN_TGX`, `Scania_R-Series`) | 55,553 | `Mercedes_Actros` | **20.3%** (11,260 / 55,553) |
| 25 | `Refuse` | Medium | `(25.0, 16.0, 9.0)` | `Volvo_FL` (1 model) | 9,738 | `Volvo_FL` | **100.0%** (9,738 / 9,738) |
| 26 | `Timber` | Heavy | `(60.0, 26.0, 40.0)` | `Scania_S-Series V8` (1 model) | 9,366 | `Scania_S-Series V8` | **100.0%** (9,366 / 9,366) |
| 27 | `Tipper` | Medium | `(24.0, 12.0, 6.0)` | `DAF_LF` (1 model) | 7,372 | `DAF_LF` | **100.0%** (7,372 / 7,372) |
| 28 | `Tipper` | Medium | `(32.0, 18.0, 10.0)` | `Iveco_Eurocargo` (1 model) | 7,612 | `Iveco_Eurocargo` | **100.0%** (7,612 / 7,612) |
| 29 | `Tipper` | Heavy | `(44.0, 26.0, 24.0)` | `MAN_TGX` (1 model) | 5,963 | `MAN_TGX` | **100.0%** (5,963 / 5,963) |
| **Total** | **10 Categories** | **3 Tiers** | **29 Buckets** | **24 Deterministic Buckets + 5 Shared Buckets** | **391,204** | **Overall Track B** | **70.50% (275,804 / 391,204)** |

### 5.3 Ready-to-Run Python Code for Cell 34 (`### Modeling`)

```python
# ==============================================================================
# CELL 34: BASELINE MACHINE LEARNING MODELING PIPELINE (TRACK A & TRACK B)
# ==============================================================================

# 1. Domain Feature Engineering (resolving collinearity among duration, distance, fuel)
model_df = vtd_df.copy()

start_dt = pd.to_datetime(model_df['trip_start_time'])
end_dt = pd.to_datetime(model_df['trip_end_time'])

model_df['trip_duration_hours'] = model_df['trip_duration'] / 3600.0
model_df['avg_speed_kmh'] = model_df['total_distance'] / model_df['trip_duration_hours']
model_df['fuel_efficiency_km_per_l'] = model_df['total_distance'] / model_df['total_fuel']
model_df['fuel_consumption_l_per_100km'] = (model_df['total_fuel'] / model_df['total_distance']) * 100.0
model_df['fuel_burn_rate_l_per_hr'] = model_df['total_fuel'] / model_df['trip_duration_hours']
model_df['trip_span_days'] = (end_dt - start_dt).dt.days
model_df['trip_month'] = start_dt.dt.month
model_df['trip_dayofweek'] = start_dt.dt.dayofweek

# 2. Define Leakage-Free Feature Sets
# Strictly exclude deterministic ID/leakage columns:
# ['manufacturer', 'Model', 'Group', 'wmi', 'plant', 'Serial Number', 'Region']
telemetry_num_features = [
    'trip_duration', 'total_distance', 'total_fuel', 'axle_weight_average',
    'avg_speed_kmh', 'fuel_efficiency_km_per_l', 'fuel_consumption_l_per_100km',
    'fuel_burn_rate_l_per_hr', 'trip_span_days', 'trip_month', 'trip_dayofweek'
]
spec_num_features = ['GCW', 'GVW', 'Capacity']
cat_features = ['special_need', 'Country']

# Set include_vehicle_specs = True for Track B (~70.5% accuracy) or False for Track A (~40.8% accuracy)
include_vehicle_specs = True
num_features = telemetry_num_features + (spec_num_features if include_vehicle_specs else [])

X = model_df[num_features + cat_features]
y = model_df[target_col]

# 3. Stratified Train-Test Split (80% Train / 20% Test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, stratify=y, random_state=42
)
print(f"Training set shape: {X_train.shape} | Test set shape: {X_test.shape}")

# 4. Preprocessing ColumnTransformer
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, num_features),
        ('cat', categorical_transformer, cat_features)
    ]
)

# 5. Train & Benchmark Baseline Classifiers
baseline_models = {
    "Logistic Regression (Multinomial Baseline)": LogisticRegression(
        max_iter=300, n_jobs=-1, random_state=42
    ),
    "Decision Tree (Depth=12 Baseline)": DecisionTreeClassifier(
        max_depth=12, min_samples_leaf=20, random_state=42
    ),
    "Random Forest (100 Trees, Depth=15)": RandomForestClassifier(
        n_estimators=100, max_depth=15, min_samples_leaf=10, n_jobs=-1, random_state=42
    )
}

results = []
trained_pipelines = {}

for model_name, clf in baseline_models.items():
    start_t = time.time()
    pipe = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', clf)
    ])
    pipe.fit(X_train, y_train)
    y_pred = pipe.predict(X_test)
    elapsed = time.time() - start_t

    acc = accuracy_score(y_test, y_pred)
    prec_macro = precision_score(y_test, y_pred, average='macro', zero_division=0)
    f1_macro = f1_score(y_test, y_pred, average='macro', zero_division=0)
    f1_weighted = f1_score(y_test, y_pred, average='weighted', zero_division=0)

    results.append({
        "Model": model_name,
        "Accuracy": round(acc, 4),
        "Macro Precision": round(prec_macro, 4),
        "Macro F1": round(f1_macro, 4),
        "Weighted F1": round(f1_weighted, 4),
        "Fit + Predict Time (s)": round(elapsed, 2)
    })
    trained_pipelines[model_name] = pipe
    print(f"[DONE] {model_name}: Accuracy={acc:.4f}, Macro F1={f1_macro:.4f} ({elapsed:.1f}s)")

results_df = pd.DataFrame(results)
display(results_df)

# 6. Detailed Classification Report & Confusion Matrix for Best Baseline Model
best_model_name = results_df.sort_values(by="Macro F1", ascending=False).iloc[0]["Model"]
best_pipe = trained_pipelines[best_model_name]
y_best_pred = best_pipe.predict(X_test)

print(f"\n=== Classification Report: {best_model_name} ===")
print(classification_report(y_test, y_best_pred, digits=4))

plt.figure(figsize=(14, 11))
cm = confusion_matrix(y_test, y_best_pred, labels=best_pipe.classes_)
sns.heatmap(
    cm, annot=False, cmap="Blues",
    xticklabels=best_pipe.classes_, yticklabels=best_pipe.classes_
)
plt.title(f"Confusion Matrix — {best_model_name}", fontsize=14, fontweight="bold")
plt.xlabel("Predicted Make_n_Model")
plt.ylabel("Actual Make_n_Model")
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()

# 7. Save Best Baseline Pipeline Artifact
joblib.dump(best_pipe, "baseline_fleet_classifier_pipeline.joblib")
print("Saved baseline model pipeline to 'baseline_fleet_classifier_pipeline.joblib'")
```
